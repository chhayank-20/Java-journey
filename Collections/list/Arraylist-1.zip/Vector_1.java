// import java.util.*;
import java.util.Vector;
public class Vector_1 {
    public static void main(String[] args) {
        Vector v = new Vector();   
        v.add("we are we ");
        v.add("telescope");

        System.out.println(v);
        System.out.println(v.firstElement());
    }
}
