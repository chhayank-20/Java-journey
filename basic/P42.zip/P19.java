class P19{

    public static void main(String args[]){

        int l,b,h,a1,a2;
        l=7;
        a1=l*l*l;
        b=4;
        h=8;
        a2=l*b*h;
        if(a1>a2)
        System.out.println("Cube");
        else 
        System.out.println("Cuboid");
    }
}