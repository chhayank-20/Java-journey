class P8{

    public static void main(String []args){

        double alt=20,area=0.8;
        area=0.8*100*100;
        double base=(area*2)/alt;
        System.out.println(base);
    }
}