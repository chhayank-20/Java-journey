class P32{

    public static void main(String []args){

        int l,a1,a2;
        l=150;
        a1=l*l;
        l=25;
        a2=l*l;
        a2=a1-a2;
        System.out.print(a2);
    }
}