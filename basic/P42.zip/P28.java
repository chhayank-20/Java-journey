class P28{

    public static void main(String []args){

        int l,b,rate,cost;
        l=5;
        b=4;
        rate=205;
        cost=l*b*rate;
        System.out.print(cost);
    }
}