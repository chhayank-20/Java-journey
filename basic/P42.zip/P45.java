class P45{

    public static void main(String []args){

         int a,b,d,n,sum;
         a=-21;
         b=-18;
         d=b-a;
         n=28;
         sum=(n*(2*a+((n-1)*d)))/2;
         System.out.print(sum);
    }
}