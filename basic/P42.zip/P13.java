class P13{

    public static void main(String []a){

        double area=184,length1=16,length2;
        length2=(2*area)/length1;
        System.out.println(length2);
    }
}