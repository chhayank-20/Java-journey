class P42{

    public static void main(String []args){

        double a,v;
        a=2.25;
        v=(22/7.0)*a*a*a;
        System.out.print(v);

    }
}