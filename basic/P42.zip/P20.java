class P20{

    public static void main(String args[]){

        int l,b,h,a;
        l=25;
        b=10;
        h=8;
        a=l*b*h;
        System.out.println(a);
    }
}