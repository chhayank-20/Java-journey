class P25{

    public static void main(String args[]){

        int n,l,b,a;
        n=100;
        l=24;
        b=15;
        a=l*b;
        a=a*n;
        System.out.println(a);
    }
}