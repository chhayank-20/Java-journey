class P36{

    public static void main(String []args){

        double d,h,sa;
        d=15;
        h=7;
        sa=(22/7.0)*(d/2)*h*2;
        System.out.print(sa);
    }
}