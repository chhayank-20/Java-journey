class P35{

    public static void main(String []args){

        double r,h,sa;
        r=7.2;
        h=12;
        sa=(22/7)*r*h*2;
        System.out.print(sa);
    }
}