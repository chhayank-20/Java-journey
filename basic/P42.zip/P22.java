class P22{

    public static void main(String args[]){

        int l,b,h,v;
        l=50;
        b=30;
        h=2;
        v=l*b*h;
        System.out.println(v);
    }
}