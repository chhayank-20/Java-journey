class P41{

    public static void main(String []args){

        double r,h,v;
        r=30/2;
        h=50;
        v=(22/7.0)*r*r*h;
        System.out.print(v);
    }
}