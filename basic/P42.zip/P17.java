class P17{

    public static void main(String []args){

        int l,b,p;
        l=3;
        b=2;
        p=2*(l+b);
        System.out.println(p);
    }
}