class P44{

    public static void main(String []args){

        int a,b,d,n,t;
        a=-21;
        b=-18;
        d=b-a;
        n=28;
        t=a+((n-1)*d);
        System.out.print(t);
    }
}