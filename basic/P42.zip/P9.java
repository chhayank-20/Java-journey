class P9{

    public static void main(String []args){

        double a,area;
        a=12;
        area=(Math.sqrt(3)/4)*a*a;
        System.out.println(area);
    }
}