class P30{

    public static void main(String []args){
        int l,b,a1,a2,n;
        l=5;
        b=8;
        a1=l*b;
        l=200;
        b=400;
        a2=l*b;
        n=a2/a1;
        System.out.print(n);
    }
}