class P29{

    public static void main(String []args){

        int l,b,a1,a2,n;
        l=10;
        a1=l*l;
        l=800;
        b=900;
        a2=l*b;
        n=a2/a1;
        System.out.print(n);
    }
}