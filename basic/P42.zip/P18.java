class P18{

    public static void main(String []args){

        int l,b,p,dist;
        l=50;b=30;
        p=2*(l+b);
        dist=p*10;
        System.out.println(dist);
    }
}