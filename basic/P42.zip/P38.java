class P38{

    public static void main(String []args){

        double r,h,v,a;
        v=1287;
        r=10;
        h=v/((22/7.0)*r*r);
        a=2*(22/7.0)*r*h;
        System.out.print(a);
    }
}