class P27{

    public static void main(String []args){

        int l,b,rate,cost;
        l=20;
        b=15;
        rate=5;
        cost=l*b*rate;
        System.out.println(cost);
    }
}