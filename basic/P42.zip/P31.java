class P31{

    public static void main(String []args){

        int p,l,a;
        p=200;
        l=p/4;
        a=l*l;
        System.out.print(a);
    }
}