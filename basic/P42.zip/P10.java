class P10{

    public static void main(String a[]){

        double side=15,area;
        area=(1.0/2)*side*side;
        System.out.println(area);
    }
}