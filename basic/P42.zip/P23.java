class P23{

    public static void main(String args[]){

        int l,b,h,v,v1,n;
        l=3;
        v=l*l*l;
        l=15;
        b=9;
        h=12;
        v1=l*b*h;
        n=v1/v;
        System.out.println(n);
    }
}