/*Find the height of a triangle whose base is 50 cm and whose area is 500 cm². */
class P7{

        public static void main(String[] args){

                double base=50,area=500;
                double height=2*(area/base);
                System.out.println(height);
        }
}