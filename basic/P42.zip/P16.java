class P16{

    public static void main(String []args){

        int l,b,a;
        l=7;
        b=5;
        a=l*b;
        System.out.println(a);
    }
}