class P43{

    public static void main(String[] args){

        double h,s,r,area;
        h=4;
        s=5;
        r=(s*s)-(h*h);
        area=(22/7.0)*r;
        System.out.print("Cost = "+(area*10));
    }
}