class P21{

    public static void main(String []args){

        float l,b,h,a1,a,n;
        l=15;
        b=8;
        h=5;
        a1=l*b*h;
        l=15;
        b=10;
        h=8;
        a=l*b*h*1000000;
        n=a/a1;
        System.out.println(n);
    }
}