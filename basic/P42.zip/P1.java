import java.util.Scanner;
class P1{

    public static void main(String []args){

        double p=230;
        double l=70;
        double b=p/2-l;
        System.out.println("Breadth of reatangle = "+b);
        double area=l*b;
        System.out.println("area of reatangle = "+area);
    }
}