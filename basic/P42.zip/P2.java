class P2{

    public static void main(String []args){

        double area = 96;
        double b = 8;
        double l=area/b;
        double par =2*(l+b);
        System.out.println("Length of rectangle "+l);
         System.out.println("Parameter of rectangle "+par);
    }
}