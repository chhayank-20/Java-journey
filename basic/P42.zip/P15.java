class P15{

    public static void main(String []args){

        int l,b,a1,a2;
        l=20;
        b=15;
        a1=l*b;
        int side=21;
        a2=side*side;
        if(a1>a2)
        System.out.println("Shelly's garden is bigger");
        else
        System.out.println("Shelly's garden is bigger");
    }
}