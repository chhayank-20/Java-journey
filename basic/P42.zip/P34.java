class P34{

    public static void main(String []args){

        int b1,b2,h,a1,b,a2,a;
        b1=92;
        b2=128;
        h=40;
        a1=((b1+b2)*h)/2;
        b=4;
        a2=h*b;
        a=a1-a2;
        System.out.print(a);
    }
}