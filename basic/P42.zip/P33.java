class P33{

    public static void main(String[] args){

        int l=30;
        int b=20;
        int a=l*b;
        int l1=30;
        int b1=3;
        int a1=l1*b1;
        int l2=4;
        int b2=20;
        int a2=l2*b2;
        int l3=3;
        int b3=4;
        int a3=l3;
        int area=a-((a1+a2)-a3);
        System.out.print(area);
    }
}