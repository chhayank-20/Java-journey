class P14{

    public static void main(String []args){

        double quadrilateral=46,h1=13,h2=10;
        double area=(quadrilateral*(h1+h2))/2;
        System.out.println(area);
    }
}