class P39{

    public static void main(String []args){

    double r,h,a,d=12;
    r=d/2;
    h=9;
    a=2*(22/7.0)*r*h;
    System.out.print(a);
    }
}