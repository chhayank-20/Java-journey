class P3{

    public static void main(String []args){

        double l1=520, l2=13;
        double b1=140, b2=7;
        double area1 = l1*b1;
        double area2 =l2*b2;
        double tile=area1/area2;
        System.out.println("Total tiles required = "+tile);
    }
}