class P26{

    public static void main(String []args){

        double l,b,a1,a2;
        l=120*100;
        b=2.4*100;
        a1=l*b;
        l=24;
        b=15;
        a2=l*b;
        double n=a1/a2;
        System.out.println(n);
    }
}